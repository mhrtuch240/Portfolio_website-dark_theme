// Preloader Animation
window.addEventListener("load", () => {
  const preloader = document.querySelector(".preloader");
  preloader.style.opacity = "0";
  setTimeout(() => {
    preloader.style.display = "none";
  }, 500); // Delay to allow fade-out animation
});

// Typing Effect for Hero Section
const typedTextSpan = document.querySelector(".typed-text");
const textArray = ["Web Developer", "Freelancer", "Programmer"];
const typingDelay = 200;
const erasingDelay = 100;
const newTextDelay = 2000;
let textArrayIndex = 0;
let charIndex = 0;

function type() {
  if (charIndex < textArray[textArrayIndex].length) {
    typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
    charIndex++;
    setTimeout(type, typingDelay);
  } else {
    setTimeout(erase, newTextDelay);
  }
}

function erase() {
  if (charIndex > 0) {
    typedTextSpan.textContent = textArray[textArrayIndex].substring(0, charIndex - 1);
    charIndex--;
    setTimeout(erase, erasingDelay);
  } else {
    textArrayIndex++;
    if (textArrayIndex >= textArray.length) textArrayIndex = 0;
    setTimeout(type, typingDelay + 1100);
  }
}

document.addEventListener("DOMContentLoaded", function() {
  if (textArray.length) setTimeout(type, newTextDelay + 250);
});

// Dark & Light Mode Toggle
const modeToggle = document.querySelector(".mode-toggle");
const body = document.body;

modeToggle.addEventListener("click", () => {
  body.classList.toggle("light-mode");
  const isLightMode = body.classList.contains("light-mode");
  modeToggle.innerHTML = isLightMode ? "☀️" : "🌙";
  localStorage.setItem("theme", isLightMode ? "light" : "dark");
});

// Check for saved theme in localStorage
const savedTheme = localStorage.getItem("theme");
if (savedTheme === "light") {
  body.classList.add("light-mode");
  modeToggle.innerHTML = "☀️";
} else {
  body.classList.remove("light-mode");
  modeToggle.innerHTML = "🌙";
}

// Smooth Scrolling for Navigation Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener("click", function(e) {
    e.preventDefault();
    document.querySelector(this.getAttribute("href")).scrollIntoView({
      behavior: "smooth"
    });
  });
});

// Scroll-to-Top Button
const scrollToTopBtn = document.getElementById("scroll-to-top");

window.addEventListener("scroll", () => {
  if (window.scrollY > 300) {
    scrollToTopBtn.style.display = "block";
  } else {
    scrollToTopBtn.style.display = "none";
  }
});

scrollToTopBtn.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
});

// Form Submission Animation
const contactForm = document.getElementById("contact-form");

contactForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const submitBtn = contactForm.querySelector("button");
  submitBtn.textContent = "Sending...";
  submitBtn.disabled = true;
  
  // Simulate form submission delay
  setTimeout(() => {
    submitBtn.textContent = "Sent ✅";
    submitBtn.style.backgroundColor = "#4CAF50"; // Green color for success
    setTimeout(() => {
      submitBtn.textContent = "Send Message";
      submitBtn.style.backgroundColor = "#00a8ff"; // Reset to original color
      submitBtn.disabled = false;
      contactForm.reset(); // Reset form fields
    }, 2000); // Reset after 2 seconds
  }, 1500); // Simulate a 1.5-second delay for sending
});

// Hover Effects for Service Cards
const serviceCards = document.querySelectorAll(".service-card");

serviceCards.forEach(card => {
  card.addEventListener("mouseenter", () => {
    card.style.transform = "translateY(-10px)";
    card.style.boxShadow = "0 10px 20px rgba(0, 168, 255, 0.4)";
  });
  
  card.addEventListener("mouseleave", () => {
    card.style.transform = "translateY(0)";
    card.style.boxShadow = "0 5px 15px rgba(0, 168, 255, 0.2)";
  });
});

// Hover Effects for Portfolio Cards
const portfolioItems = document.querySelectorAll(".portfolio-item");

portfolioItems.forEach(item => {
  item.addEventListener("mouseenter", () => {
    item.style.transform = "translateY(-10px)";
    item.style.boxShadow = "0 10px 20px rgba(0, 168, 255, 0.4)";
  });
  
  item.addEventListener("mouseleave", () => {
    item.style.transform = "translateY(0)";
    item.style.boxShadow = "0 5px 15px rgba(0, 168, 255, 0.2)";
  });
});